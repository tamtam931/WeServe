<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Auth extends CI_Controller {
    public $user= "";
	public function __construct() {
            parent::__construct();
            $this->output->enable_profiler(FALSE);
        }
    public function index()
    {

        //  print_r($this->multiple_random_strings_encrypt($array)); exit;
        //var_dump($this->dec_enc('MUdHOEdXZVpYVDBlZUtvWHZpL2Vqdz09','decrypt')); exit;
       // print_r(get_headers("https://apps1.theestatemakati.ph/strcihold/"));exit;
        if (!logged_in()) {

            $data = array(
                'page' => "",
                'page_title' => "Sign in"
            );
            $this->load->view('header', $data);
            $this->load->view('auth/account');
            $this->load->view('footer');
           
        } else {
            
            redirect('auth');
        }

    }

    public function login()
    {
        
        if (logged_in()) {
            redirect('buyer/main', 'refresh');
        }

        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        $error = "";
        if ($this->form_validation->run()) {
            // $checker = $this->auth_model->login_log_checker(set_value('username'));
            
            // if($checker) {
            //     // still logged in
            //     $error = 'One login per user only. Logout on other devices.';
               
            // } else {
                if ($this->authme->signin( set_value('username'), set_value('password') )) {
                    // save to DB
                    // $this->auth_model->save_login_log(user('vendor_id'), $this->generateRandomString());
                     $this->dashboard();
                } else {
                    $error = 'Invalid Username and/or Password.';
                }
            // }
            
        }
      
        $data = array(
            'page' => "",
            'page_title' => "Sign in",
            'error' => $error
        );
        $this->load->view('header', $data);
        $this->load->view('auth/account');
        $this->load->view('footer');
    }

    public function dashboard()
    {
        if(user('role_id') == 2) {
            // Vendor
            redirect('buyer/main/'.user('id'), 'refresh');
        } elseif(user('role_id') == 1) {
            // Admin
            redirect('admin/main/'.user('id'), 'refresh');
        } elseif(user('role_id') == 3) {
            // Treasury
            redirect('treasury/main/'.user('id'), 'refresh');
        } elseif(user('role_id') == 4) {
            // Sales Admin
            redirect('sales_admin/main/'.user('id'), 'refresh');
        } elseif(user('role_id') == 5) {
            // Sales Admin
            redirect('viewer/main/'.user('id'), 'refresh');
        }
        
       
    }
    
    public function logout()
    {
        // $user = $this->Reservation_model->get_vendor_details($this->uri->segment(3));
        // $this->auth_model->remove_log($user->vendor_id);
        if (!logged_in()) {
            redirect('/');
        } else {
            $this->authme->signout('/');
            
        }
    }

   public function generateRandomString($length = 6) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function forgot_details() {
        $email = $this->input->post('email');
        $details = $this->Reservation_model->get_vendor_details_by_email($email);
        $length = 6;
        $randomString = "";
        $randomString = substr(str_shuffle(str_repeat($x='abcdefghijklmnopqrstuvwxyz', ceil($length/strlen($x)) )),1,$length);

        // update pw status and password itself
        

       
        if($details) {
			$this->Reservation_model->update_password_and_status($details->id, $this->dec_enc( $randomString, 'encrypt'));
            $data = array(
                'email' => $details->email,
                'firstname' => $details->firstname,
                'vendor_id' => $details->vendor_id,
                'password' => $randomString
            );
            $result = $this->send_email($data);

            //$notif = "Your Credentials has been sent to your Email Successfully!";
            //echo "<script type='text/javascript'>alert('Your Credentials has been sent to your Email Successfully!');</script>";
          
        } else {
            //$notif = "You have encountered an error in sending Email.";
            echo "<script type='text/javascript'>alert('ERROR: Email Address is not registered.');</script>";
        }

       redirect('auth', 'refresh');

      
    }

    public function send_email($data){
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From:  <no-reply@theestatemakati.com>"; 
        $subject = "Account Credentials";
        $msg = "Hi ".$data['firstname'].", You can use the Account Access details below for <b>https://apps.theestatemakati.ph/strcihold</b>: </br><br /> Vendor Code: ".$data['vendor_id']. "</br><br /> One-time Password: " .$data['password']."</br><br /> You'll be required to  your password on your first login. </br> Have a great day! 
            </br></br> <h3>PLEASE DO NOT REPLY TO THIS EMAIL. THIS IS AN AUTO-GENERATED MESSAGE.</h3>";
        $result = mail($data['email'],$subject,$msg, $headers);
        //var_dump($result); exit;
        if($result == true) {
            echo "<script type='text/javascript'>alert('Your Credentials has been sent to your Email Successfully!');</script>";

        } else {
            echo "<script type='text/javascript'>alert('You have encountered an error in sending Email.');</script>";
        }
        
        redirect('auth', 'refresh');

    }

     public function dec_enc($string, $action) {
        // you may change these values to your own
        $secret_key = 'my_simple_secret_key';
        $secret_iv = 'my_simple_secret_iv';
     
        $output = false;
        $encrypt_method = "AES-256-CBC";
        $key = hash( 'sha256', $secret_key );
        $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
     
        if( $action == 'encrypt' ) {
            $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
        }
        else if( $action == 'decrypt' ){
            $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
        }
     
        return $output;
    }

    public function multiple_random_strings_encrypt($array) {
        $values = array();
        for ($x = 0; $x <= count($array); $x++) {
            # code...
            $values[] = $this->dec_enc($array[$x], 'encrypt');
        }
        return implode( "<br>", $values );
    }

   

  
}