<?php

class Admin extends CI_Controller {
    
    public $user_id = '';
    public $role_id = '';

	public function __construct() {
        parent::__construct();
        $this->user_id = user('id');
        $this->role_id = user('role');
        $this->load->library('user_agent');
    }
	public function index($data = null) {
      
	}

   public function main() {
        $this->load->view('header');
        $this->load->view('admin/main');
        $this->load->view('footer');
   }

    public function dashboard() {
        $this->load->view('header');
        $this->load->view('admin/dashboard');
        $this->load->view('footer');
   }

    public function schedule() {
        $this->load->view('header');
        $this->load->view('admin/schedule');
        $this->load->view('footer');
   }

    public function administration() {
        $data = array(
            'positions' => $this->Admin_model->get_positions()
        );
        $this->load->view('header');
        $this->load->view('admin/administration', $data);
        $this->load->view('footer');
   }

  

}


