<?php

class auth_model extends CI_Model {
       
    public function __construct() {
        parent::__construct();
        
    }
    
    public function login( $username = null, $password = null ) {
       $this->db->select("*"); 
       $this->db->where('vendor_id', $username);
       $this->db->where('password', $password);
       $this->db->from('tbl_vendors');
       $query = $this->db->get();
        
       return $query->row();
    }
    
    public function signup( $data = null ) {
       $this->db->insert('users', $data);
    }

    public function save_login_log($user_id, $key) {
      $data = array(
        'vendor_id' => $user_id,
        'session_key' =>$key
      );
      $this->db->insert('tbl_user_log', $data);
    }

    public function login_log_checker( $vendor_id ) {
       $this->db->select("*"); 
       $this->db->from('tbl_user_log');
       $this->db->where('tbl_user_log.vendor_id', $vendor_id);
       $query = $this->db->get();
       return $query->row();
    }
    
     public function remove_log($vendor_id){
        $this -> db -> delete('tbl_user_log', array('vendor_id' => $vendor_id));
    }
    
 
}