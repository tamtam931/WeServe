<?php

class Admin_model extends CI_Model {
       
    public function __construct() {
        parent::__construct();
        
    }
    
    public function get_positions() {
       $this->db->select("*"); 
       $this->db->from('tbl_position');
       $query = $this->db->get();
       return $query->result();
    }
    
    
    
 
}