
  <div class="bg-dark navbar-dark text-white">
    <div class="container">
      <nav class="navbar px-0 navbar-expand-lg navbar-dark">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a href="<?= base_url('admin/main') ?>" class="pl-md-0 p-3 text-white">Home</a>
            <a href="<?= base_url('admin/dashboard') ?>" class="p-3 text-decoration-none text-white">Turnover Dashboard</a>
            <a href="<?= base_url('admin/schedule') ?>" class="p-3 text-decoration-none text-white">Turnover Schedule</a>
            <a href="<?= base_url('admin/administration') ?>" class="p-3 text-decoration-none text-white">Administration</a>
          </div>
        </div>
      </nav>

    </div>
  </div>
