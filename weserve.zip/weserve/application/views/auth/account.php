<?= $this->load->view('header', '', TRUE) ?>

<div class="container py-5 mb5">
  <h2 style="color: red; font-weight: bolder;"><center>DEVELOPMENT ENVIRONMENT</center></h2>          
  <header class="page-header">
     <!-- date time here -->
  </header>
     
  <div class="row py-4">
    <div class="col-md-4 order-md-2 mb-4">

      <div class="card card-primary" style="width: 68rem;">
        <div class="card-header text-center" style= "background-color: #536391;color: #fff;height: 100px;">
          <span style= "font-size: 25px;font-weight: 600;letter-spacing: 2px;"> WeServe </span><br>
          <i>Signin</i>
        </div>
        <div class="card-body">
         
          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="username">Username</label>
              <input type="text" class="form-control" id="username" placeholder="" value="" required>
              <div class="invalid-feedback">
                Valid first name is required.
              </div>

              <label for="password">Password</label>
              <input type="password" class="form-control" id="password" placeholder="" value="" required>
              <div class="invalid-feedback">
                Valid last name is required.
              </div>

              <hr class="mb-4">
              <button class="btn btn-primary btn-lg" type="submit">LOGIN</button>
            </div>

            <div class="col-md-6 mb-3">
              <img src="<?= base_url('assets/img/FLI.png') ?>" class="img-responsive" style=" right: 0; bottom: 0; width: 90%; height: 140px;" alt="">
            </div>


          </div>
            

        </div>
      </div>

    </div>
  </div>

</div>