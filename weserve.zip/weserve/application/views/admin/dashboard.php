<?= $this->load->view('top', '', TRUE) ?>
DASHBOARD