<?= $this->load->view('top', '', TRUE) ?>

<div class="container py-5 mb5">
  <h3 class="mb-3">ADMINISTRATION</h3>

  	<div class="row">
	    <div class="col-md-3">
	        <form class="mb-3">
	          <div class="input-group">
	            <input type="text" class="form-control" placeholder="Search">
	            <div class="input-group-append">
	              <button type="submit" class="btn btn-primary">Search</button>
	            </div>
	          </div>
	        </form>

	        <div class="list-group">
	          <a href="#" class="list-group-item list-group-item-action active"> Accounts Management </a>
	          <a href="#" class="list-group-item list-group-item-action">Change Password</a>
	        </div>

	    </div>

	    <div class="col-md-9">

	    	<form class="needs-validation" novalidate>
        		<div class="row">
			    	<div class="col-md-4 mb-3">
			            <label for="firstname">First Name</label>
			            <input type="text" class="form-control" id="firstname" placeholder="" value="" required>
			            <div class="invalid-feedback">
			              First Name is required.
			            </div>
			        </div>
			        <div class="col-md-4 mb-3">
			            <label for="middlename">Middle Name</label>
			            <input type="text" class="form-control" id="middlename" placeholder="" value="" required>
			            <div class="invalid-feedback">
			              Middle Name is required.
			            </div>
			        </div>
			        <div class="col-md-4 mb-3">
			            <label for="lastname">Last Name</label>
			            <input type="text" class="form-control" id="lastname" placeholder="" value="" required>
			            <div class="invalid-feedback">
			              Last Name is required.
			            </div>
			        </div>
			    </div>

			    <div class="col-md-4 mb-3">
			    	 <label for="country">Position</label>
		            <select class="custom-select d-block w-100" id="country" required>
		            	<?php foreach($positions as $position): ?>
		              	<option value=""><?= $position->position_desc; ?></option>
		              	<?php endforeach; ?>
		            </select>
		            <div class="invalid-feedback">
		              Please select a Position.
		            </div>
			    </div>

			    <div class = "row">
				    <div class="col-md-4 mb-3">
			            <label for="username">Username</label>
			            <div class="input-group">
				            <div class="input-group-prepend">
				              <span class="input-group-text"><i class="fa fa-address-card"></i></span>
				            </div>
				            <input type="text" class="form-control" id="username" placeholder="Username" required>
				            <div class="invalid-feedback" style="width: 100%;">
				              Username is required.
				            </div>
				        </div>
			        </div>

			         <div class="col-md-4 mb-3">
			            <label for="username">Password</label>
			            <div class="input-group">
				            <div class="input-group-prepend">
				              <span class="input-group-text"><i class="fa fa-lock"></i></span>
				            </div>
				            <input type="text" class="form-control" id="password" placeholder="Password" required>
				            <div class="invalid-feedback" style="width: 100%;">
				              Password is required.
				            </div>
				        </div>
			        </div>
			    </div>
		        <div class="col-md-6 mb-3 float-right">
       				<button class="btn btn-dark my-2 mr-2 text-oswald btn-wide" type="submit">Save</button>
       				<button class="btn btn-outline-dark my-2 text-oswald btn-wide" type="dismiss">Cancel</button>
       			</div>
			</form>

	    	<table class="table">
			  <thead class="thead-light">
			    <tr>
			      <th scope="col">First Name</th>
			      <th scope="col">Middle Name</th>
			      <th scope="col">Last Name</th>
			      <th scope="col">Position</th>
			      <th scope="col">Status</th>
			      <th scope="col">Option</th>
			    </tr>
			  </thead>
			  <tbody>
			  
			    <tr>
			      <th scope="row">Viel</th>
			      <th scope="row">Bernabe</th>
			      <th scope="row">Parale</th>
			      <th scope="row">web Developer</th>
			      <th scope="row">Active</th>
			      <td>
			        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
			          <span class="fas fa-edit mr-1"></span>
			          Edit</a>
			        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
			          <span class="fas fa-trash mr-1"></span>
			          Delete</a>
			      </td>
			    </tr>

			    <tr>
			      <th scope="row">Jane</th>
			      <th scope="row">Clay</th>
			      <th scope="row">Doe</th>
			      <th scope="row">Architect</th>
			      <th scope="row">Active</th>
			      <td>
			        <a href="#" class="btn btn-sm btn-primary my-1 my-sm-0">
			          <span class="fas fa-edit mr-1"></span>
			          Edit</a>
			        <a href="#" class="btn btn-sm btn-danger my-1 my-sm-0">
			          <span class="fas fa-trash mr-1"></span>
			          Delete</a>
			      </td>
			    </tr>
			  
			  
			  
			  </tbody>
			</table>
	    </div>
	</div>
</div>