<?= $this->load->view('top', '', TRUE) ?>

HELLO THERE